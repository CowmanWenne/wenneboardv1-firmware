#include "wenneboardv1.h"

uint8_t g_current_app_vol = APP_VOL_SYSTEM;

void encoder_update_user(uint8_t index, bool clockwise) {
    if (index == 0) {
        if (clockwise) {
            tap_code(KC_VOLU);
        } else {
            tap_code(KC_VOLD);
        }
    } else if (index == 1) {
        if (clockwise) {
            switch (g_current_app_vol) {
                case APP_VOL_SYSTEM: tap_code(KC_VOLU); break;
                case APP_VOL_CHROME: SEND_STRING(SS_TAP(X_RALT, X_VOLU)); break;
                case APP_VOL_DISCORD: SEND_STRING(SS_TAP(X_RCTL, X_VOLU)); break;
            }
        } else {
            switch (g_current_app_vol) {
                case APP_VOL_SYSTEM: tap_code(KC_VOLD); break;
                case APP_VOL_CHROME: SEND_STRING(SS_TAP(X_RALT, X_VOLD)); break;
                case APP_VOL_DISCORD: SEND_STRING(SS_TAP(X_RCTL, X_VOLD)); break;
            }
        }
    }
}

bool process_record_user(uint16_t keycode, keyrecord_t *record) {
    if (record->event.pressed) {
        if (keycode == KC_APP_VOL_NEXT) {
            g_current_app_vol++;
            if (g_current_app_vol > APP_VOL_DISCORD) {
                g_current_app_vol = APP_VOL_SYSTEM;
            }
            return false;
        }
    }
    return true;
}

void action_encoder_click(uint8_t index) {
    if (index == 0) {
        tap_code(KC_MUTE);
    } else if (index == 1) {
        tap_code16(KC_APP_VOL_NEXT);
    }
}
