enum {
    APP_VOL_SYSTEM,
    APP_VOL_CHROME,
    APP_VOL_DISCORD
};

extern uint8_t g_current_app_vol;

#define KC_APP_VOL_NEXT SAFE_RANGE